from model.data_utils import CoNLLDataset
from model.ner_model import NERModel
from model.config import Config
import nltk
from string import punctuation
from tika import parser
from parse import Parse
parseobj = Parse()


punct_list  = list(set(list(punctuation)))


def align_data(data):
    """Given dict with lists, creates aligned strings

    Adapted from Assignment 3 of CS224N

    Args:
        data: (dict) data["x"] = ["I", "love", "you"]
              (dict) data["y"] = ["O", "O", "O"]

    Returns:
        data_aligned: (dict) data_align["x"] = "I love you"
                           data_align["y"] = "O O    O  "

    """
    spacings = [max([len(seq[i]) for seq in data.values()])
                for i in range(len(data[list(data.keys())[0]]))]
    data_aligned = dict()

    # for each entry, create aligned string
    for key, seq in data.items():
        str_aligned = ""
        for token, spacing in zip(seq, spacings):
            str_aligned += token + " " * (spacing - len(token) + 1)

        data_aligned[key] = str_aligned

    return data_aligned

# nerTags={'B-LOCATION':'I-LOCATION','B-ROLE':'I-ROLE','O':'','B-SUFFIX':'','B-ORGS':'I-ORGS','B-SKILL':'I-SKILL'}
nerTags={'B-LOCATION':'I-LOCATION','B-ROLE':'I-ROLE','O':'','B-SUFFIX':'','B-ORGS':'I-ORGS','B-SKILL':'I-SKILL'}

def genEntity(zippedData):
    zippedData = [i for i in zippedData if i[1] != 'O']
    #suffixesData = [i for i in zippedData if i[1] == 'B-SUFFIX']
    tagGrammer=""
    NerEntities={}
    for beginTag,endTag in (nerTags.items()):
       # "role: {<B-ROLE><I-ROLE>*}"
        tagGrammer=str(beginTag)+": {<"+beginTag+"><"+endTag+">*}"
        Entities=nltk.RegexpParser(tagGrammer)
        EntitiesList=[]
        for s in Entities.parse(zippedData):
            if (type(s) is nltk.tree.Tree):
                EntitiesList.append(" ".join([i for i, j in (s)]))
        #print(EntitiesList)
        NerEntities[beginTag]=EntitiesList
    return (NerEntities)
    #print("suffixesData: ",suffixesData)

def getEntities(zippedData):
    zippedData = [i for i in zippedData if i[1] != 'O']
    X = 'B-'
    #print(zippedData)

    rolegrammar = "role: {<B-ROLE><I-ROLE>*}"
    skillgrammar = "Skill: {<B-SKILL><I-SKILL>*}"
    role1 = nltk.RegexpParser(rolegrammar)
    skill1 = nltk.RegexpParser(skillgrammar)
    roles = []
    skills = []

    # role1result = role1.parse(zippedData)
    for s in skill1.parse(zippedData):
        if (type(s) is nltk.tree.Tree):
            skills.append(" ".join([i for i, j in (s)]))
    for r in role1.parse(zippedData):
        if (type(r) is nltk.tree.Tree):
            # print(j)
            roles.append(" ".join([i for i, j in (r)]))
    return skills,roles



        # else:
        #     print("no entity for w :",w)

def interactive_shell(model):
    """Creates interactive shell to play with model

    Args:
        model: instance of NERModel

    """
    model.logger.info("""
This is an interactive mode.
To exit, enter 'exit'.
You can enter a sentence like
input> I am a java developer in delhi""")

    while True:
        try:
            # for python 2
            sentence = raw_input("input> ")

        except NameError:
            # for python 3
            sentence = input("input> ")
        sentence=sentence.replace(","," , ")
        words_raw = sentence.strip().split(" ")

        if words_raw == ["exit"]:
            break

        preds = model.predict(words_raw)

        # zippedData=list(zip(words_raw,preds))
        #skills,roles=getEntities(zippedData)
        #print( "Skills :",skills)
        #print("Roles :", roles)
        # NerEntities=genEntity(zippedData)
        print(preds)


def readfile(filename):
    '''
    read file
    return format :
    '''
    f = open(filename)
    f=f.readlines()
    return f



def interactive_shell2(model):
    """Creates interactive shell to play with model

    Args:
        model: instance of NERModel

    """
    pdfFile=r"/Users/prasingh/Prashant/Prashant/CareerBuilder/pdftablereader/Bank_Statement_Parser/BankStatementParser/main/TableExtractor/Citibank/2016/10416361010216030300/1-2016 MM Acct. Stmt..pdf"
    # pdfFile=r"/Users/prasingh/Prashant/Prashant/CareerBuilder/pdftablereader/Bank_Statement_Parser/Bank_Of_America_Training_Data/extract_data/BankOfAmeica/10401424325217082300/eStmt_2017-02-28 AC 6869.pdf"
    from pdf2image import convert_from_path
    import os
    import pytesseract
    from PIL import Image

    folder = "working"
    if os.path.isdir("working") == False:
        os.makedirs("working")

    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
        except Exception as e:
            print(e)


    pages = convert_from_path(pdfFile)
    for pagenum, page in enumerate(pages):
        newfilename_temp = str(pagenum) + ".jpg"
        page.save(os.path.join("working", newfilename_temp), 'JPEG')

    files = list(os.listdir("working"))
    files.sort(key=lambda f: int(f.replace(".jpg", '')))

    files = [os.path.join("working", i) for i in files]
    print(files)

    pdfData = []
    words_map = {}
    ### Extract text from Images
    for file in files:
        alltext = pytesseract.image_to_string(Image.open(file))
        alltext = alltext.split("\n")
        alltext = [i for i in alltext if i != '']
        for text in alltext:
            sentence = text.lower().replace("/"," ").replace("&","and")
            for p in punct_list:
                sentence = sentence.replace(p, "")
            words_raw = sentence.strip().split(" ")
            preds = model.predict(words_raw)
            print(text)
            print(preds)
            print("---------" * 10)
            if len(list(set(preds)))>1:

                zippedData = list(zip(words_raw,preds))
                # print(zippedData)

                stringData = ''
                currLabel = ''
                for d in zippedData:

                    if "B-" in d[1]:
                        if stringData!='':
                            try:
                                if stringData not in words_map[currLabel]:
                                    words_map[currLabel].append(stringData)
                            except:
                                words_map[currLabel] = []
                                words_map[currLabel].append(stringData)

                            stringData = ''
                        else:
                            stringData = stringData+' '+d[0]
                            currLabel = d[1].replace("B-", '')

                    elif "I-" in d[1]:
                        stringData = stringData + ' ' + d[0]
                        # currLabel = d[1].replace("I-", '')
                if stringData!='':
                    # words_map[currLabel] = stringData
                    try:
                        # if stringData not in words_map[currLabel]:
                            words_map[currLabel].append(stringData)
                    except:
                        words_map[currLabel] = []
                        words_map[currLabel].append(stringData)

    print(words_map)


def interactive_shell3(model):
    """Creates interactive shell to play with model

    Args:
        model: instance of NERModel

    """
    pdfFile=r"/Users/prasingh/Prashant/Prashant/CareerBuilder/pdftablereader/Bank_Statement_Parser/BankStatementParser/main/TableExtractor/Citibank/citibank/10416361010216030300/1-2016 MM Acct. Stmt..pdf"
    # pdfFile=r"/Users/prasingh/Prashant/Prashant/CareerBuilder/pdftablereader/Bank_Statement_Parser/Bank_Of_America_Training_Data/extract_data/BankOfAmeica/10401424325217082300/eStmt_2017-02-28 AC 6869.pdf"
    PDF_Parse = parser.from_file(pdfFile)
    contents = PDF_Parse['content']
    contents = contents.split("\n")
    alltext = [con for con in contents if con != '' and len(con) > 0]
    words_map = {}
    # alltext = alltext.split("\n")
    for text in alltext:

        sentence = text.lower()
        for p in punct_list:
            sentence = sentence.replace(p, "")
        sentence = parseobj.parse(sentence)
        words_raw = sentence.strip().split(" ")
        preds = model.predict(words_raw)
        print(text)
        print(preds)
        print("---------" * 10)
        if len(list(set(preds)))>1:

            zippedData = list(zip(words_raw,preds))
            # print(zippedData)

            stringData = ''
            currLabel = ''
            for d in zippedData:

                if "B-" in d[1]:
                    if stringData!='':
                        try:
                            if stringData not in words_map[currLabel]:
                                words_map[currLabel].append(stringData)
                        except:
                            words_map[currLabel] = []
                            words_map[currLabel].append(stringData)

                        stringData = ''
                    else:
                        stringData = stringData+' '+d[0]
                        currLabel = d[1].replace("B-", '')

                elif "I-" in d[1]:
                    stringData = stringData + ' ' + d[0]
                    # currLabel = d[1].replace("I-", '')
            if stringData!='':
                # words_map[currLabel] = stringData
                try:
                    if stringData not in words_map[currLabel]:
                        words_map[currLabel].append(stringData)
                except:
                    words_map[currLabel] = []
                    words_map[currLabel].append(stringData)

    print(words_map)
# new_word_map = {}



def main():
    # create instance of config
    config = Config()

    # build model
    model = NERModel(config)
    model.build()
    model.restore_session(config.dir_model)

    # create dataset
    test  = CoNLLDataset(config.filename_test, config.processing_word,
                         config.processing_tag, config.max_iter)

    # evaluate and interact
    #model.evaluate(test)
    interactive_shell(model)

def loadmodel():
    config = Config()

    # build model
    model = NERModel(config)
    model.build()
    model.restore_session(config.dir_model)
    return model

def apiRequest(sentence,model):
    sentence = sentence.replace(",", " , ")
    words_raw = sentence.strip().split(" ")
    preds = model.predict(words_raw)
    zippedData = list(zip(words_raw, preds))
    # skills,roles=getEntities(zippedData)
    # print( "Skills :",skills)
    # print("Roles :", roles)
    NerEntities = genEntity(zippedData)
    return (NerEntities)


if __name__ == "__main__":

    main()
    #apiRequest("i am java developer")