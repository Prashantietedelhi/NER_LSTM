
from model.data_utils import CoNLLDataset

from model.ner_model import NERModel
from model.config import Config
import nltk
from string import punctuation
from pdf2image import convert_from_path
import os
import pytesseract
from PIL import Image
class DataExtractor:

    def __init__(self):
        self.punct_list = list(set(list(punctuation)))
        config = Config()

        # build model
        self.model = NERModel(config)
        self.model.build()
        self.model.restore_session(config.dir_model)

    def get_classified(self, pdfFile):
        if ".pdf" not in pdfFile:
            raise Exception("Only accept pdf files")
        folder = "working"
        if os.path.isdir("working") == False:
            os.makedirs("working")

        for the_file in os.listdir(folder):
            file_path = os.path.join(folder, the_file)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                print(e)

        pages = convert_from_path(pdfFile)
        for pagenum, page in enumerate(pages):
            newfilename_temp = str(pagenum) + ".jpg"
            page.save(os.path.join("working", newfilename_temp), 'JPEG')

        files = list(os.listdir("working"))
        files.sort(key=lambda f: int(f.replace(".jpg", '')))

        files = [os.path.join("working", i) for i in files]
        words_map = {}
        for file in files:
            alltext = pytesseract.image_to_string(Image.open(file))
            alltext = alltext.split("\n")
            alltext = [i for i in alltext if i != '']
            for text in alltext:
                sentence = text.lower().replace("/", " ").replace("&", "and")
                for p in self.punct_list:
                    sentence = sentence.replace(p, "")
                words_raw = sentence.strip().split(" ")
                preds = self.model.predict(words_raw)
                # print(text)
                # print(preds)
                # print("---------" * 10)
                if len(list(set(preds))) > 1:

                    zippedData = list(zip(words_raw, preds))
                    # print(zippedData)

                    stringData = ''
                    currLabel = ''
                    for d in zippedData:

                        if "B-" in d[1]:
                            if stringData != '':

                                try:
                                    # if stringData not in words_map[currLabel]:
                                    stringData = stringData.strip().lower()
                                    words_map[currLabel][stringData] = words_map[currLabel][stringData]+1
                                except Exception as e:
                                    # print(e)
                                    try:
                                        stringData = stringData.strip().lower()
                                        words_map[currLabel][stringData] = 1
                                    except:
                                        words_map[currLabel] = {}
                                        words_map[currLabel][stringData] = 1

                                stringData = ''
                            else:
                                stringData = stringData + ' ' + d[0]
                                currLabel = d[1].replace("B-", '')

                        elif "I-" in d[1]:
                            stringData = stringData + ' ' + d[0]
                            # currLabel = d[1].replace("I-", '')
                    if stringData != '':
                        # words_map[currLabel] = stringData q
                        try:
                            # if stringData not in words_map[currLabel]:
                            stringData = stringData.strip().lower()
                            words_map[currLabel][stringData] = words_map[currLabel][stringData] + 1
                        except Exception as e:
                            # print(e)
                            stringData = stringData.strip().lower()
                            try:
                                words_map[currLabel][stringData] = 1
                            except:
                                words_map[currLabel] = {}
                                words_map[currLabel][stringData] = 1

        return  words_map

if __name__=="__main__":
    file  = r"/Users/prasingh/Prashant/Prashant/CareerBuilder/pdftablereader/Birddogs-BofA-Bank-Statement-April.pdf"
    obj = DataExtractor()
    data = obj.get_classified(file)
    print(data)

    # obj = DataExtractor()
    data = obj.get_classified(file)
    print(data)

