# Parse
# Authors: <Singh, Prashant <Prashant.Singh@Monsterindia.com>>
#          <Sharma, Shashikant <Shashikant.Sharma@Monsterindia.com>>
'''
The Parse library is used for cleaning the data.

'''

import re, os,json
import string



class Parse():
    def __init__(self):
        self.printable = set(string.printable)

    def parse(self, source):
        '''
        parse funciton is resposible for removing punctuations marks and unicode characters
        :param source: String input
        :return: junk removed string
        '''
        self.source = source

        ########remove unicodes and non printable characters
        self.source = re.sub(r'[^\x00-\x7F]', ' ', self.source)
        ######## removing all non printable characters
        self.source = ''.join(filter(lambda x: x in self.printable, self.source))
        ####### remove white space from the beginning of the line
        self.source = re.sub(r'^( +)', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ####### remove lines containing number followed by dot(.) that appearing in the text
        self.source = re.sub(r'(^\s*\d+.\r*\n)|^( +)', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ###### removing one or more whitespaces from the begining and end of each line
        self.source = re.sub(r'(^( +)|( +)$)', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ###### removing all jpeg embedded in document
        self.source = re.sub(r'((\!\[\]\(data:image\/).*\r*\n)', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ###### remove any blank images embedded in document
        self.source = re.sub(r'((\!\[\]\(data:\)))', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ###### remove starting digits and '#' symbols
        # self.source = re.sub(r'(^\s*[^a-zA-Z]+\s*)', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ###### remove one or more whitespaces from the beginning and end of each line
        self.source = re.sub(r'(^( +)|( +)$)', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ###### remove multiple new lines
        self.source = re.sub(r'(\n+)', r'\n', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ############ remove whitespace with single space
        self.source = re.sub(' +', ' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        ######## remove line containg numbers followed by dot(.)
        self.source = re.sub(r'(^\s*)(\d+.)(\r*\n)', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        self.source = re.sub(r'&#x22;', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        self.source = re.sub(r'x22;', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        self.source = re.sub(r'&#x22;', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        self.source = re.sub(r'&#x27;', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        self.source = re.sub(r'x27;', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        self.source = re.sub(r'\\\\', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)
        self.source = re.sub(r'//', r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)

        junk_list = ['xa4', 'xa4', 'xa7', 'xe6', 'xa9', 'xa6', 'xa8', 'u201a', 'u02dc', 'xbf', 'xba', 'u02dc', 'u2014',
                     'u2026', 'u2020', 'xbc', 'xef', 'u2022', 'u2122', 'xe5', 'xbd', 'x9d', 'xe7', 'xe2', 'xb8', 'xe8',
                     'u017d', 'xb4', 'xae', 'x90', 'xbb', 'xa5', 'u0192', 'xa0', 'u2018', 'xe9', 'u201c', 'xb5',
                     'u2013', 'xb6', 'u203a', 'u20ac', 'xb7', 'u0153', 'xb0', 'u201e', 'xc3', 'xaf', 'xa1', 'xe4',
                     'xad', 'xa2', 'xc2', 'xb9', 'u2026 - ']
        for j in junk_list:
            self.source = re.sub(j, r' ', self.source, flags=re.IGNORECASE | re.MULTILINE)



        return self.source



if __name__=='__main__':
    obj = Parse()
    print(obj.parse("CITIBUSINESS IMMA  202911889"))
    # import time
    # st=time.time()
    # print(obj.parse("c++"))
    # print(time.time()-st)
    # st = time.time()
    # print(obj.parse("big-data"))
    # print(time.time() - st)


